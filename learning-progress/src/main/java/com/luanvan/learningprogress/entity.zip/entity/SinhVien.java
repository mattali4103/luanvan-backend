    package com.luanvan.learningprogress.entity;

    import jakarta.persistence.*;
    import lombok.*;
    import lombok.experimental.FieldDefaults;

    import java.time.LocalDate;
    import java.util.List;

    @AllArgsConstructor
    @NoArgsConstructor
    @Getter
    @Setter
    @Entity
    @FieldDefaults(level = AccessLevel.PRIVATE)
    @Table(name = "sinh_vien")
    public class SinhVien {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        private String KhoaHoc;

        @ManyToOne
        @JoinColumn(name = "lop_ma_lop")
        private Lop lop;

        @OneToMany(mappedBy = "sinh_vien")
        private List<KetQuaHocTap> ketQuaHocTap;

        @OneToMany(mappedBy = "sinhVien")
        private List<KeHoachHocTap> keHoachHocTap;
        @ManyToOne
        @JoinColumn(name = "user_id")
        User user;
    }