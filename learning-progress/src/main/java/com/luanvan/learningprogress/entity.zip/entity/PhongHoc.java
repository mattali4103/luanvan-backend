package com.luanvan.learningprogress.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;
import lombok.experimental.FieldDefaults;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
@Entity
public class PhongHoc {
    @Id
    String ma_phong;
    String ma_nha_hoc;
    int suc_chua;
    int tiet_hoc;
    int tiet_trong;
}
